export class User {
  constructor(
    public userId: number,
    public userName: string,
    public userType: number,
    public userPassword: string,
    public userEmail: string,
    public userBirth: string,
    public userSex: number,
    public userGrade: number,
    public userChips: string,
    public userIdu: string,
  ) {
  }
}

export class Book {
  constructor(
    public bookId: number,
    public bookName: string,
    public bookAuthor: string,
    public bookPub: string,
    public bookCount: number,
  ) {
  }
}

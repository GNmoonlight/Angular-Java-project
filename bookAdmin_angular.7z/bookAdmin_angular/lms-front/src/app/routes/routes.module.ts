import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {LoginComponent} from '../views/login/login.component';
import {HomeComponent} from '../views/home/home.component';
import {RegisterComponent} from '../views/register/register.component';
import {MainComponent} from '../views/main/main.component';
import {BrbooksComponent} from '../views/brbooks/brbooks.component';
import {ManbooksComponent} from '../views/manbooks/manbooks.component';
import {HistoryComponent} from '../views/history/history.component';
import {ManusersComponent} from '../views/manusers/manusers.component';

const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent,
  },
  {
    path: 'register',
    component: RegisterComponent
  },
  {
    path: 'home',
    component: HomeComponent,
    children: [
      {
        path: 'main',
        component: MainComponent
      },
      {
        path: 'brbooks',
        component: BrbooksComponent
      },
      {
        path: 'manbooks',
        component: ManbooksComponent
      },
      {
        path: 'history',
        component: HistoryComponent
      },
      {
        path: 'manusers',
        component: ManusersComponent
      },
      {
        path: '**',
        pathMatch: 'full',
        redirectTo: 'main'
      },
    ]
  },
  {
    path: '**',
    pathMatch: 'full',
    redirectTo: '/login'
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
}

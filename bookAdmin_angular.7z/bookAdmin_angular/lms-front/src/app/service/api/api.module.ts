import {NgModule} from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import {UserService} from './user.service';
import {RestService} from './rest.service';
import {BookService} from './book.service';

@NgModule({
  imports: [HttpClientModule],
  providers: [UserService, RestService, BookService]
})
export class ApiModule {
}

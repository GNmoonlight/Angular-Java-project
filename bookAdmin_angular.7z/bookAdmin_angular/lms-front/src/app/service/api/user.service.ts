import {Injectable} from '@angular/core';
import {HttpParams} from '@angular/common/http';
import {Observable} from 'rxjs';
import {RestService} from './rest.service';

@Injectable()
export class UserService {

  constructor(private restService: RestService) {
  }

  login(params: HttpParams): Observable<any> {
    return this.restService.sendRequest<any>('POST', `/user/login`, params);
  }

  register(params: HttpParams): Observable<any> {
    return this.restService.sendRequest<any>('POST', `/user/register`, params);
  }

  getUserByName(params: HttpParams): Observable<any> {
    return this.restService.sendRequest<any>('POST', `/user/getUserByName`, params, sessionStorage.getItem('token'));
  }

  updateUser(body: any): Observable<any> {
    return this.restService.sendJsonRequest('POST', `/user/updateUser`, body, sessionStorage.getItem('token'));
  }

  getMostUser(): Observable<any> {
    return this.restService.sendJsonRequest('POST', `/user/getMostUser`, {}, sessionStorage.getItem('token'));
  }
}

import {Injectable} from '@angular/core';
import {RestService} from './rest.service';
import {Observable} from 'rxjs';
import {HttpParams} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HistoryService {

  constructor(private restService: RestService) {
  }

  addBhistory(body: any): Observable<any> {
    return this.restService.sendJsonRequest('POST', `/history/addBhistory`, body, sessionStorage.getItem('token'));
  }

  returnBhistory(body: any): Observable<any> {
    return this.restService.sendJsonRequest('POST', `/history/returnBhistory`, body, sessionStorage.getItem('token'));
  }

  getAllLhistory(params: HttpParams): Observable<any> {
    return this.restService.sendRequest<any>('POST', `/history/getLhistoryByUserId`, params, sessionStorage.getItem('token'));
  }
}

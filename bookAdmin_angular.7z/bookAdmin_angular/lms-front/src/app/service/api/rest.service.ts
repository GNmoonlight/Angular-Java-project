import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders, HttpParams} from '@angular/common/http';
import {Observable, throwError} from 'rxjs';
import {catchError} from 'rxjs/operators';
import {Router} from '@angular/router';
import {NotifierService} from '../notifier.service';

@Injectable()
export class RestService {

  constructor(private http: HttpClient, private router: Router, private notifierService: NotifierService) {
  }

  private url = `/api`;

  errorAction = err => {
    if (err.status === 403) {
      this.notifierService.showNotification('登录已过期，请重新登陆', '确认');
      this.router.navigateByUrl('/');
    } else {
      this.notifierService.showNotification('查询失败，无法连接服务器', '确认');
    }
    return throwError(err);
  }

  sendRequest<T>(verb: string, uri: string, params?: HttpParams, token?: string): Observable<T> {
    return this.http.request<T>(verb, this.url + uri, token ? {
      params, headers: new HttpHeaders({token})
    } : {params}).pipe(catchError(this.errorAction));
  }

  sendJsonRequest<T>(verb: string, uri: string, body: any, token?: string): Observable<T> {
    return this.http.request<T>(verb, this.url + uri, token ? {body, headers: new HttpHeaders({token})} : {body})
      .pipe(catchError(this.errorAction));
  }
}

import {Injectable} from '@angular/core';
import {RestService} from './rest.service';
import {HttpParams} from '@angular/common/http';
import {Observable} from 'rxjs';

@Injectable()
export class BookService {

  constructor(private restService: RestService) {
  }

  getAllBooks(params: HttpParams): Observable<any> {
    return this.restService.sendRequest<any>('POST', `/book/getAllBooks`, params, sessionStorage.getItem('token'));
  }

  updateBook(body: any): Observable<any> {
    return this.restService.sendJsonRequest('POST', `/book/updateBook`, body, sessionStorage.getItem('token'));
  }

  deleteBook(params: HttpParams): Observable<any> {
    return this.restService.sendRequest<any>('POST', `/book/deleteBook`, params, sessionStorage.getItem('token'));
  }

  addBook(body: any): Observable<any> {
    return this.restService.sendJsonRequest('POST', `/book/addBook`, body, sessionStorage.getItem('token'));
  }

  getPopularBook(): Observable<any> {
    return this.restService.sendJsonRequest('POST', `/book/getPopularBook`, {}, sessionStorage.getItem('token'));
  }

  borrowBook(params: HttpParams): Observable<any> {
    return this.restService.sendRequest<any>('POST', `/book/borrowBook`, params, sessionStorage.getItem('token'));
  }

  returnBook(params: HttpParams): Observable<any> {
    return this.restService.sendRequest<any>('POST', `/book/returnBook`, params, sessionStorage.getItem('token'));
  }
}

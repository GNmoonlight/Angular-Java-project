import {AfterViewInit, Component, OnInit, ViewChild} from '@angular/core';
import {Book} from '../../models/user.model';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {BookService} from '../../service/api/book.service';
import {NotifierService} from '../../service/notifier.service';
import {Router} from '@angular/router';
import {HttpParams} from '@angular/common/http';
import {MatDialog} from '@angular/material/dialog';
import {EbdialogComponent} from './ebdialog/ebdialog/ebdialog.component';

@Component({
  selector: 'app-manbooks',
  templateUrl: './manbooks.component.html',
  styleUrls: ['./manbooks.component.scss']
})
export class ManbooksComponent implements OnInit, AfterViewInit {
  displayedColumns: string[] = ['bookId', 'bookName', 'bookAuthor', 'bookPub', 'bookCount', 'action'];
  dataSource: Book[] = [];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  firstExpand = true;
  scroll;
  total: number;
  isLoadingResults = true;
  submitForm = {
    bookId: '',
    bookName: '',
    bookAuthor: '',
    bookPub: ''
  };


  constructor(private bookService: BookService,
              private notifierService: NotifierService,
              private router: Router, public dialog: MatDialog) {
  }

  ngAfterViewInit(): void {
    this.getAllBooks();
  }

  ngOnInit(): void {
  }

  getAllBooks(): void {
    this.isLoadingResults = true;
    const params = new HttpParams().appendAll({
      ...this.submitForm,
      pageSize: this.paginator.pageSize.toString(),
      pageNum: (this.paginator.pageIndex + 1).toString()
    });
    this.bookService.getAllBooks(params).subscribe(
      resp => {
        this.dataSource = resp.list;
        this.total = parseInt(resp.total, 10);
        this.isLoadingResults = false;
      }
      , error => {
        if (error.status === 403) {
          this.notifierService.showNotification('登录已过期，请重新登陆', '确认');
          this.router.navigateByUrl('/');
        } else if (error.status === 404) {
          this.notifierService.showNotification('查询失败，无法连接服务器', '确认');
        }
      });
  }

  openEditDialog(row): void {
    const dialogRef = this.dialog.open(EbdialogComponent, {data: {...row, openCode: 0}});
    dialogRef.afterClosed().subscribe(result => {
      if (result.actionCode === 1) {
        this.bookService.updateBook(result.data).subscribe(resp => {
          if (resp.code === 1) {
            this.notifierService.showNotification('编辑成功', '确认');
          } else {
            this.notifierService.showNotification('编辑失败', '确认');
          }
          this.getAllBooks();
        });
      } else if (result.actionCode === -1) {
        const params = new HttpParams().appendAll({bookId: row.bookId});
        console.log(params);
        this.bookService.deleteBook(params).subscribe(resp => {
          if (resp.code === 1) {
            this.notifierService.showNotification('删除成功', '确认');
          } else {
            this.notifierService.showNotification('删除失败', '确认');
          }
          this.getAllBooks();
        });
      }
    });
  }

  openAddDialog(): void {
    const dialogRef = this.dialog.open(EbdialogComponent,
      {data: {openCode: 1, bookName: '', bookAuthor: '', bookPub: '', bookCount: ''}});
    dialogRef.afterClosed().subscribe(result => {
      if (result.actionCode === 1) {
        this.bookService.addBook(result.data).subscribe(resp => {
          this.notifierService.showNotification(resp.message, '确认');
          this.getAllBooks();
        });
      }
    });
  }

}

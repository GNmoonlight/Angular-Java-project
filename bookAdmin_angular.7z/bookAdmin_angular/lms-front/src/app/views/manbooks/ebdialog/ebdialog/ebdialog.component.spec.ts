import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EbdialogComponent } from './ebdialog.component';

describe('EbdialogComponent', () => {
  let component: EbdialogComponent;
  let fixture: ComponentFixture<EbdialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EbdialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EbdialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

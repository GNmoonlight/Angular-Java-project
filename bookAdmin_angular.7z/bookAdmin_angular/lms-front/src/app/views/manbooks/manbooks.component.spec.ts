import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManbooksComponent } from './manbooks.component';

describe('ManbooksComponent', () => {
  let component: ManbooksComponent;
  let fixture: ComponentFixture<ManbooksComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManbooksComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManbooksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

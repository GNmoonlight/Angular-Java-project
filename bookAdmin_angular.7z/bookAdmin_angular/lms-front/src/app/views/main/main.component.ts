import {AfterViewInit, Component, OnInit} from '@angular/core';
import {NotifierService} from '../../service/notifier.service';
import {Router} from '@angular/router';
import {BookService} from '../../service/api/book.service';
import {UserService} from '../../service/api/user.service';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss']
})
export class MainComponent implements OnInit, AfterViewInit {

  bookDisplayedColumns: string[] = ['bookId', 'bookName', 'bookAuthor', 'bookPub', 'bookCount', 'bookPopular'];
  userDisplayedColumns: string[] = ['userName', 'userGrade', 'mostUser'];
  bookDataSource = [];
  userDataSource = [];

  constructor(
    private notifierService: NotifierService,
    private router: Router,
    private bookService: BookService,
    private userService: UserService) {
  }

  ngOnInit(): void {
  }

  ngAfterViewInit(): void {
    this.getPopularBook();
    this.getMostUser();
  }

  getPopularBook(): void {
    this.bookService.getPopularBook().subscribe(
      resp => {
        console.log(resp);
        this.bookDataSource = resp;
      }
);
  }

  getMostUser(): void {
    this.userService.getMostUser().subscribe(
      resp => {
        console.log(resp);
        this.userDataSource = resp;
      }
);
  }

}

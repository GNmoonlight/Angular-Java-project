import {AfterViewInit, Component, OnInit, ViewChild} from '@angular/core';
import {HttpParams} from '@angular/common/http';
import {MatPaginator} from '@angular/material/paginator';
import {NotifierService} from '../../service/notifier.service';
import {Router} from '@angular/router';
import {HistoryService} from '../../service/api/history.service';

export type Lhistory = {
  userId: number,
  userName: string,
  userType: number,
  loginTime: string
};

@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.scss']
})
export class HistoryComponent implements OnInit, AfterViewInit {

  dataSource: Lhistory [] = [];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  total: number;
  displayedColumns: string[] = ['userId', 'userName', 'userType', 'loginTime'];
  userId: '';

  constructor(private notifierService: NotifierService, private router: Router, private historyService: HistoryService) {
  }

  ngAfterViewInit(): void {
    this.getAllHistory();
  }

  ngOnInit(): void {
  }

  getAllHistory(): void {
    const params = (!this.userId || this.userId === '') ? new HttpParams().appendAll({
      pageSize: this.paginator.pageSize.toString(),
      pageNum: (this.paginator.pageIndex + 1).toString()
    }) : new HttpParams().appendAll({
      userId: this.userId,
      pageSize: this.paginator.pageSize.toString(),
      pageNum: (this.paginator.pageIndex + 1).toString()
    });
    this.historyService.getAllLhistory(params).subscribe(
      resp => {
        this.dataSource = resp.list;
        this.total = parseInt(resp.total, 10);
      });
  }

}

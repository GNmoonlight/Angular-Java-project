import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {UserService} from '../../service/api/user.service';
import {HttpParams} from '@angular/common/http';
import {NotifierService} from '../../service/notifier.service';
import {FormControl, FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  isActive = false;
  // 表单
  public loginFormControl = new FormGroup({
    username: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required, Validators.pattern('^(?![0-9]+$)(?![a-z]+$)(?![A-Z]+$)(?!([^(0-9a-zA-Z)])+$).{6,20}$')])
  });

  // 表单验证逻辑
  public getError = {
    username: () => {
      if (this.loginFormControl.controls.username.hasError('required')) {
        return '请输入用户名';
      }
    },
    password: () => {
      if (this.loginFormControl.controls.password.hasError('required')) {
        return '请输入密码';
      } else if (this.loginFormControl.controls.password.hasError('pattern')) {
        return '密码需包含 数字,英文,字符中的两种以上，长度6-20';
      }
    }
  };

  public hide = true;

  constructor(public router: Router, private userService: UserService, private notifierService: NotifierService) {
  }

  ngOnInit(): void {
  }

  // 登录逻辑
  login(): void {
    if (!this.loginFormControl.invalid) {
      const params = new HttpParams()
        .appendAll(this.loginFormControl.value);
      this.userService.login(params).subscribe(
        resp => {
          if (resp.code === 1) {
            this.router.navigateByUrl('/home');
            sessionStorage.setItem('token', resp.token);
            sessionStorage.setItem('userName', this.loginFormControl.value.username);
            sessionStorage.setItem('userType', resp.userType);
            sessionStorage.setItem('userId', resp.userId);
            this.notifierService.showNotification(resp.message, '确认');
          } else {
            this.notifierService.showNotification(resp.message, '确认');
          }
        }
      );
    }
  }
}

import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {UserService} from '../../service/api/user.service';
import {HttpParams} from '@angular/common/http';
import {NotifierService} from '../../service/notifier.service';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';
import {MAT_MOMENT_DATE_FORMATS, MomentDateAdapter} from '@angular/material-moment-adapter';
import * as moment from 'moment';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {MyErrorStateMatcher} from '../../../utils/utils';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss'],
  providers: [
    {provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},
    {provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS},
  ],
})
export class RegisterComponent implements OnInit {
  public isActive = false;
  public myErrorStateMatcher = new MyErrorStateMatcher();
  public hide = true;
  public registerForm = new FormGroup({
    username: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required, Validators.pattern('^(?![0-9]+$)(?![a-z]+$)(?![A-Z]+$)(?!([^(0-9a-zA-Z)])+$).{6,20}$')]),
    confirmPassword: new FormControl(''),
    userEmail: new FormControl('', [Validators.required, Validators.email]),
    userGrade: new FormControl('', [Validators.required]),
    userBirth: new FormControl('', [Validators.required]),
    userSex: new FormControl('', [Validators.required]),
    userChips: new FormControl('', [Validators.required]),
    userIdu: new FormControl('', [Validators.required])
  }, {validators: passwordMatchValidator});

  public getError = {
    username: () => {
      if (this.registerForm.controls.username.hasError('required')) {
        return '请输入用户名';
      }
    },
    password: () => {
      if (this.registerForm.controls.password.hasError('required')) {
        return '请输入密码';
      } else if (this.registerForm.controls.password.hasError('pattern')) {
        return '密码需包含 数字,英文,字符中的两种以上，长度6-20';
      }
    },
    confirmPassword: () => {
      if (this.registerForm.hasError('mismatch')) {
        return '两次输入的密码不一致';
      }
    },
    userEmail: () => {
      if (this.registerForm.controls.userEmail.hasError('required')) {
        return '请输入电子邮件';
      } else if (this.registerForm.controls.userEmail.hasError('email')) {
        return '电子邮件格式错误';
      }
    },
    userBirth: () => {
      if (this.registerForm.controls.userBirth.hasError('required')) {
        return '请输入生日';
      }
    },
    userSex: () => {
      if (this.registerForm.controls.userSex.hasError('required')) {
        return '请选择性别';
      }
    },
    userGrade: () => {
      if (this.registerForm.controls.userGrade.hasError('required')) {
        return '请选择所在年级';
      }
    },
    userChips: () => {
      if (this.registerForm.controls.userChips.hasError('required')) {
        return '请输入兴趣爱好';
      }
    },
    userIdu: () => {
      if (this.registerForm.controls.userIdu.hasError('required')) {
        return '请输入自我介绍';
      }
    }
  };

  constructor(public router: Router, private userService: UserService, private notifierService: NotifierService) {
  }

  ngOnInit(): void {
  }

  register(): void {
    const params = new HttpParams()
      .appendAll({...this.registerForm.value, userBirth: moment(this.registerForm.value.userBirth.toString()).format('L')});
    console.log(params);
    this.userService.register(params).subscribe(
      resp => {
        if (resp.code === 1) {
          this.router.navigateByUrl('/');
          this.notifierService.showNotification('注册成功', '确认');
        } else if (resp.code === -1) {
          this.notifierService.showNotification('用户已存在', '确认');
        } else {
          this.notifierService.showNotification('注册失败', '确认');
        }
      }
    );
  }
}

function passwordMatchValidator(g: FormGroup): object {
  return g.get('password').value === g.get('confirmPassword').value
    ? null : {mismatch: true};
}

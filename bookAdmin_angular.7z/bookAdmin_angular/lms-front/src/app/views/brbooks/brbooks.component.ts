import {AfterViewInit, Component, OnInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {HttpParams} from '@angular/common/http';
import {BookService} from '../../service/api/book.service';
import {Book} from '../../models/user.model';
import {NotifierService} from '../../service/notifier.service';
import {Router} from '@angular/router';
import {HistoryService} from '../../service/api/history.service';

/**
 * @title Data table with sorting, pagination, and filtering.
 */
@Component({
  selector: 'app-brbooks',
  templateUrl: './brbooks.component.html',
  styleUrls: ['./brbooks.component.scss']
})
export class BrbooksComponent implements OnInit, AfterViewInit {
  public userType: boolean = sessionStorage.getItem('userType') === '1';
  displayedColumns: string[] = this.userType ? ['bookId', 'bookName', 'bookAuthor', 'bookPub', 'bookCount', 'action'] : ['bookId', 'bookName', 'bookAuthor', 'bookPub', 'bookCount'];
  dataSource: Book[] = [];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  firstExpand = true;
  scroll;
  total: number;
  isLoadingResults = false;
  submitForm = {
    bookId: '',
    bookName: '',
    bookAuthor: '',
    bookPub: ''
  };
  userId: number;
  returnForm = {
    userId: '',
    bookId: '',
    returnBook: null
  };


  constructor(private bookService: BookService,
              private notifierService: NotifierService,
              private router: Router,
              private historyService: HistoryService) {
  }

  ngAfterViewInit(): void {
    this.getAllBooks();
  }

  ngOnInit(): void {
  }

  getAllBooks(): void {
    this.isLoadingResults = true;
    const params = new HttpParams().appendAll({
      ...this.submitForm,
      pageSize: this.paginator.pageSize.toString(),
      pageNum: (this.paginator.pageIndex + 1).toString()
    });
    this.bookService.getAllBooks(params).subscribe(
      resp => {
        this.dataSource = resp.list;
        this.total = parseInt(resp.total, 10);
        this.isLoadingResults = false;
      });
  }

  borrowBook(raw): void {
    const params = new HttpParams().appendAll({bookId: raw.bookId, bookCount: raw.bookCount, userId: this.userId.toString()});
    this.bookService.borrowBook(params).subscribe(
      resp => {
        this.notifierService.showNotification(resp.message, '确认');
        this.getAllBooks();
      }
    );
  }

  returnBook(): void {
    const params = new HttpParams().appendAll({bookId: this.returnForm.bookId, userId: this.returnForm.userId});
    this.bookService.returnBook(params).subscribe(
      resp => {
        this.notifierService.showNotification(resp.message, '确认');
        this.getAllBooks();
      }
    );
  }

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BrbooksComponent } from './brbooks.component';

describe('BrbooksComponent', () => {
  let component: BrbooksComponent;
  let fixture: ComponentFixture<BrbooksComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BrbooksComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BrbooksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

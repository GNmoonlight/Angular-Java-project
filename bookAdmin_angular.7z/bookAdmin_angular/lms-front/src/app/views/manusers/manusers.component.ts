import {AfterViewInit, Component, OnInit} from '@angular/core';
import {HttpParams} from '@angular/common/http';
import {UserService} from '../../service/api/user.service';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {MatDialog} from '@angular/material/dialog';
import {NotifierService} from '../../service/notifier.service';
import {ManusersdialogComponent} from './manusersdialog/manusersdialog.component';
import * as moment from 'moment';

@Component({
  selector: 'app-manusers',
  templateUrl: './manusers.component.html',
  styleUrls: ['./manusers.component.scss'],
})
export class ManusersComponent implements OnInit, AfterViewInit {

  user = {
    userName: '',
    userEmail: '',
    userBirth: '',
    userSex: '',
    userGrade: '',
    userChips: '',
    userIdu: ''
  };

  public registerForm = new FormGroup({
    username: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required, Validators.pattern('^(?![0-9]+$)(?![a-z]+$)(?![A-Z]+$)(?!([^(0-9a-zA-Z)])+$).{6,20}$')]),
    confirmPassword: new FormControl(''),
    userEmail: new FormControl('', [Validators.required, Validators.email]),
    userGrade: new FormControl('', [Validators.required]),
    userBirth: new FormControl('', [Validators.required]),
    userSex: new FormControl('', [Validators.required]),
    userChips: new FormControl('', [Validators.required]),
    userIdu: new FormControl('', [Validators.required])
  }, {validators: passwordMatchValidator});

  constructor(private userService: UserService, public dialog: MatDialog, private notifierService: NotifierService) {
  }

  ngOnInit(): void {
  }

  ngAfterViewInit(): void {
    this.getUser();
  }

  getUser(): void {
    const params = new HttpParams().appendAll({userName: sessionStorage.getItem('userName')});
    this.userService.getUserByName(params).subscribe(resp => {
      console.log(resp.userBirth);
      this.user = resp;
      this.registerForm.setValue({
        username: resp.userName,
        password: resp.userPassword,
        confirmPassword: resp.userPassword,
        userEmail: resp.userEmail,
        userGrade: resp.userGrade.toString(),
        userBirth: moment(resp.userBirth).format(),
        userSex: resp.userSex.toString(),
        userChips: resp.userChips,
        userIdu: resp.userIdu
      });
      console.log(typeof this.user.userSex);
    });
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(ManusersdialogComponent,
      {data: this.registerForm});
    dialogRef.afterClosed().subscribe(result => {
      if (result.code === 1) {
        console.log('send' + result.data.value.userBirth.format('YYYY/MM/DD'));
        this.userService.updateUser({
          ...result.data.value,
          userName: result.data.value.username,
          userPassword: result.data.value.password,
          userBirth: result.data.value.userBirth.format('YYYY/MM/DD'),
          userId: sessionStorage.getItem('userId')
        }).subscribe(resp => {
          this.notifierService.showNotification(resp.message, '确认');
          this.getUser();
        });
      }
    });
  }

}

function passwordMatchValidator(g: FormGroup): object {
  return g.get('password').value === g.get('confirmPassword').value
    ? null : {mismatch: true};
}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManusersComponent } from './manusers.component';
@Component({
  selector: 'grid-list-overview-example',
  styleUrls: ['grid-list-overview-example.css'],
  templateUrl: 'grid-list-overview-example.html',
  })
describe('ManusersComponent', () => {
  let component: ManusersComponent;
  let fixture: ComponentFixture<ManusersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManusersComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManusersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

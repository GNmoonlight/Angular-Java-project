import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManusersdialogComponent } from './manusersdialog.component';

describe('ManusersdialogComponent', () => {
  let component: ManusersdialogComponent;
  let fixture: ComponentFixture<ManusersdialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManusersdialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManusersdialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

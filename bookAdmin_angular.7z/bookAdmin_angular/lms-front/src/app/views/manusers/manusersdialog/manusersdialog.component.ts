import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {MyErrorStateMatcher} from '../../../../utils/utils';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';
import {MAT_MOMENT_DATE_FORMATS, MomentDateAdapter} from '@angular/material-moment-adapter';
import * as moment from 'moment';


@Component({
  selector: 'app-manusersdialog',
  templateUrl: './manusersdialog.component.html',
  styleUrls: ['./manusersdialog.component.scss'],
  providers: [
    {provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},
    {provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS},
  ],
})
export class ManusersdialogComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<ManusersdialogComponent>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }

  public myErrorStateMatcher = new MyErrorStateMatcher();
  public hide = true;

  public getError = {
    username: () => {
      if (this.data.controls.username.hasError('required')) {
        return '请输入用户名';
      }
    },
    password: () => {
      if (this.data.controls.password.hasError('required')) {
        return '请输入密码';
      } else if (this.data.controls.password.hasError('pattern')) {
        return '密码需包含 数字,英文,字符中的两种以上，长度6-20';
      }
    },
    confirmPassword: () => {
      if (this.data.hasError('mismatch')) {
        return '两次输入的密码不一致';
      }
    },
    userEmail: () => {
      if (this.data.controls.userEmail.hasError('required')) {
        return '请输入电子邮件';
      } else if (this.data.controls.userEmail.hasError('email')) {
        return '电子邮件格式错误';
      }
    },
    userBirth: () => {
      if (this.data.controls.userBirth.hasError('required')) {
        return '请输入生日';
      }
    },
    userSex: () => {
      if (this.data.controls.userSex.hasError('required')) {
        return '请选择性别';
      }
    },
    userGrade: () => {
      if (this.data.controls.userGrade.hasError('required')) {
        return '请选择所在年级';
      }
    },
    userChips: () => {
      if (this.data.controls.userChips.hasError('required')) {
        return '请输入兴趣爱好';
      }
    },
    userIdu: () => {
      if (this.data.controls.userIdu.hasError('required')) {
        return '请输入自我介绍';
      }
    }
  };

  ngOnInit(): void {
  }

}

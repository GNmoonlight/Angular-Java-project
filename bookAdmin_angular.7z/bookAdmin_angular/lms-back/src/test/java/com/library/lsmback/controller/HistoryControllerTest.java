package com.library.lsmback.controller;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageInfo;
import com.library.lsmback.models.Bhistory;
import com.library.lsmback.models.Lhistory;
import com.library.lsmback.service.BhistoryService;
import com.library.lsmback.service.LhistoryService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.doReturn;

class HistoryControllerTest {

    @InjectMocks
    private HistoryController historyController;

    @Mock
    private LhistoryService lhistoryService;

    @Mock
    private BhistoryService bhistoryService;

    @Test
    void addBhistory() {
        MockitoAnnotations.openMocks(this);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("code", 1);
        jsonObject.put("message", "添加成功");
        Bhistory mockBhistory = new Bhistory();
        doReturn(1).when(bhistoryService).insertBhistory(mockBhistory);
        JSONObject returnJsonObject = historyController.addBhistory(mockBhistory);
        Assertions.assertEquals(jsonObject, returnJsonObject);

    }

    @Test
    void returnBHistory() {
        MockitoAnnotations.openMocks(this);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("code", 1);
        jsonObject.put("message", "更新成功");
        Bhistory mockBhistory = new Bhistory();
        doReturn(1).when(bhistoryService).returnHistory(mockBhistory);
        JSONObject returnJsonObject = historyController.returnBHistory(mockBhistory);
        Assertions.assertEquals(jsonObject, returnJsonObject);
    }

    @Test
    void getLhistoryByUserId() {
        MockitoAnnotations.openMocks(this);
        List<Lhistory> mockLhistory = new ArrayList<>();
        doReturn(mockLhistory).when(lhistoryService).selectByUserId(1);
        PageInfo returnResult = historyController.getLhistoryByUserId(1, null, null);
        Assertions.assertEquals(mockLhistory, returnResult.getList());
    }
}
package com.library.lsmback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LsmBackApplicationTests {

    @Test
    void contextLoads() {
    }

}

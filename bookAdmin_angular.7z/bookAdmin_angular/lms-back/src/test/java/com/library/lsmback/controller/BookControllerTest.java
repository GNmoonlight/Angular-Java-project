package com.library.lsmback.controller;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageInfo;
import com.library.lsmback.models.Bhistory;
import com.library.lsmback.models.Book;
import com.library.lsmback.service.BhistoryService;
import com.library.lsmback.service.BookService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.doReturn;

class BookControllerTest {

    @InjectMocks
    private BookController bookController;

    @Mock
    private static BookService bookService;

    @Mock
    private BhistoryService bhistoryService;

    /**
     * 按检索条件获取图书列表测试
     */
    @Test
    void getAllBook() {
        MockitoAnnotations.openMocks(this);
        List<Book> returnBook = new ArrayList<>();
        Book newBook = new Book();
        newBook.setBookId(2);
        newBook.setBookName("学习JAVA");
        newBook.setBookAuthor("xxxx");
        newBook.setBookPub("xxxxxxxxxx");
        newBook.setBookCount(8);
        returnBook.add(newBook);
        doReturn(returnBook).when(bookService).selectAll(
                2, "学习JAVA", "xxxx", "xxxxxxxxxx");
        PageInfo<Book> getAllBookReturn = bookController.getAllBook(
                5, 1, 2, "学习JAVA", "xxxx", "xxxxxxxxxx");
        Assertions.assertEquals(returnBook, getAllBookReturn.getList());
    }

    /**
     * 借书借口测试
     */
    @Test
    void borrowBook() {
        MockitoAnnotations.openMocks(this);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("code", 1);
        jsonObject.put("message", "借阅成功");
        Book mockBook = new Book();
        mockBook.setBookId(2);
        mockBook.setBookCount(7);
        Bhistory mockBhistory = new Bhistory();
        mockBhistory.setBookId(2);
        mockBhistory.setUserId(1);
        doReturn(1).when(bookService).updateBook(mockBook);
        doReturn(1).when(bhistoryService).insertBhistory(mockBhistory);
        JSONObject returnJsonObject = bookController.borrowBook(2, 1, 8);
        Assertions.assertEquals(jsonObject, returnJsonObject);
    }

    /**
     * 还书接口测试
     */
    @Test
    void returnBook() {
        MockitoAnnotations.openMocks(this);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("code", 1);
        jsonObject.put("message", "归还成功");
        Book mockBook = new Book();
        mockBook.setBookId(2);
        mockBook.setBookCount(8);
        Bhistory mockBhistory = new Bhistory();
        mockBhistory.setBookId(2);
        mockBhistory.setUserId(1);
        List<Book> bookList = new ArrayList<>();
        Book fakeBook = new Book();
        fakeBook.setBookCount(7);
        bookList.add(fakeBook);
        doReturn(bookList).when(bookService).selectAll(2, null, null, null);
        doReturn(1).when(bookService).updateBook(mockBook);
        doReturn(1).when(bhistoryService).returnHistory(mockBhistory);
        JSONObject returnJsonObject = bookController.returnBook(2, 1);
        Assertions.assertEquals(jsonObject, returnJsonObject);
    }

    /**
     * 更新书籍信息接口测试
     */
    @Test
    void updateBook() {
        MockitoAnnotations.openMocks(this);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("code", 1);
        jsonObject.put("message", "删除成功");
        doReturn(1).when(bookService).deleteBookById(1);
        JSONObject returnJsonObject = bookController.deleteBook(1);
        Assertions.assertEquals(jsonObject, returnJsonObject);
    }

    /**
     * 删除书籍接口测试
     */
    @Test
    void deleteBook() {
        MockitoAnnotations.openMocks(this);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("code", 1);
        jsonObject.put("message", "更新成功");
        Book newBook = new Book();
        doReturn(1).when(bookService).updateBook(newBook);
        JSONObject returnJsonObject = bookController.updateBook(newBook);
        Assertions.assertEquals(jsonObject, returnJsonObject);
    }

    @Test
    void addBook() {
        MockitoAnnotations.openMocks(this);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("code", 1);
        jsonObject.put("message", "添加成功");
        List<Book> mockBookList = new ArrayList<>();
        doReturn(mockBookList).when(bookService).selectAll(null, "example", "example", "example");
        Book mockBook = new Book();
        mockBook.setBookName("example");
        mockBook.setBookPub("example");
        mockBook.setBookAuthor("example");
        doReturn(1).when(bookService).addBook(mockBook);
        JSONObject returnJsonObject = bookController.addBook(mockBook);
        Assertions.assertEquals(jsonObject, returnJsonObject);
    }

}
package com.library.lsmback.aspect;

import com.alibaba.fastjson.JSONObject;
import com.library.lsmback.models.Lhistory;
import com.library.lsmback.models.User;
import com.library.lsmback.service.LhistoryService;
import com.library.lsmback.service.UserService;
import com.library.lsmback.utils.TokenUtil;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class LoginAspect {

    @Autowired
    private TokenUtil tokenUtil;

    @Autowired
    private UserService userService;

    @Autowired
    private LhistoryService lhistoryService;

    private final String POINT_CUT = "execution(* com.library.lsmback.controller.UserController.login(*))";

    @Pointcut(POINT_CUT)
    private void pointcut() {
    }

    @AfterReturning(value = POINT_CUT, returning = "jsonObject", argNames = "jsonObject")
    public void doAfterLogin(JSONObject jsonObject) {
        if (jsonObject.getInteger("code") == 1) {
            String token = jsonObject.getString("token");
            String userName = tokenUtil.getUserName(token);
            User currentUser = userService.selectAllByName(userName);
            Lhistory newRecord = new Lhistory();
            newRecord.setUserId(currentUser.getUserId());
            newRecord.setUserType(currentUser.getUserType());
            lhistoryService.addLhistory(newRecord);
        }
    }
}

package com.library.lsmback.utils;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.TokenExpiredException;
import com.auth0.jwt.interfaces.DecodedJWT;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class TokenUtil {

    @Value("${jwt.issuer}")
    private String ISSUER;

    @Value("${jwt.audience}")
    private String AUDIENCE;

    @Value("${jwt.expires_in}")
    private int EXPIRES_IN;

    private final String encrykey = "misiro-school";

    private final Algorithm ALGORITHM = Algorithm.HMAC256(encrykey);

    public static Boolean result = false;

    public static String message = "";

    public String generateToken(String username) {
        long currentTime = System.currentTimeMillis();

        return JWT.create()
                .withIssuer(ISSUER)
                .withIssuedAt(new Date(currentTime))
                .withExpiresAt(new Date(currentTime + (long) EXPIRES_IN * 1000 * 60))
                .withClaim("username", username)
                .sign(ALGORITHM);
    }

    public void verifyToken(String token) {
        try {
            if (null == token) {
                result = false;
                message = "token is null";
                return;
            }
            JWTVerifier verifier = JWT.require(ALGORITHM).withIssuer(ISSUER).build();
            DecodedJWT decodedJWT = verifier.verify(token);

            String issuer = decodedJWT.getIssuer();

            String username = decodedJWT.getClaim("username").asString();
            if (("").equals(username)) {
                result = false;
                message = "user is error";
                return;
            }
        } catch (TokenExpiredException e) {
            result = false;
            message = "token is expired";
            return;
        }
        result = true;
        message = "token is verified";
    }

    public String getUserName(String token) {
        JWTVerifier verifier = JWT.require(ALGORITHM).withIssuer(ISSUER).build();
        DecodedJWT decodedJWT = verifier.verify(token);

        String issuer = decodedJWT.getIssuer();

        return decodedJWT.getClaim("username").asString();
    }
}

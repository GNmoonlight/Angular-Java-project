package com.library.lsmback.mapper;

import com.library.lsmback.models.User;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface UserDao {
    int deleteByPrimaryKey(Integer userId);

    int insert(User record);

    int insertSelective(User record);

    User selectByPrimaryKey(Integer userId);

    int updateByPrimaryKeySelective(User record);

    int updateByPrimaryKey(User record);

    int selectByNamePassword(String userName, String password);

    int selectByName(String userName);

    User selectAllByName(String userName);

    List<User> getMostUser();
}
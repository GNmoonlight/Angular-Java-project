package com.library.lsmback.service.impl;

import com.library.lsmback.mapper.BhistoryDao;
import com.library.lsmback.models.Bhistory;
import com.library.lsmback.service.BhistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BhistoryServiceImpl implements BhistoryService {

    @Autowired
    private BhistoryDao bhistoryDao;

    @Override
    public int insertBhistory(Bhistory bhistory) {
        return bhistoryDao.insertSelective(bhistory);
    }

    @Override
    public int returnHistory(Bhistory bhistory) {
        return bhistoryDao.returnHistory(bhistory);
    }
}

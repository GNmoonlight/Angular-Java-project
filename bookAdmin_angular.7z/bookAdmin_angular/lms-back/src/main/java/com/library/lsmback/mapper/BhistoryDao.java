package com.library.lsmback.mapper;

import com.library.lsmback.models.Bhistory;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BhistoryDao {
    int insert(Bhistory record);

    int insertSelective(Bhistory record);

    int returnHistory(Bhistory record);
}
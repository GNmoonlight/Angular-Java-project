package com.library.lsmback.models;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * user
 *
 * @author
 */
public class User implements Serializable {
    private Integer userId;

    private String userName;

    private Integer userType;

    private String userPassword;

    private String userEmail;

    @JsonFormat(locale = "zh", timezone = "GMT+8", pattern = "yyyy/MM/dd")
    private Date userBirth;

    private Integer userSex;

    private Integer userGrade;

    private String userChips;

    private String userIdu;

    private Date userStartDate;

    private Date userEndDate;

    private Integer mostUser;

    private static final long serialVersionUID = 1L;

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Integer getUserType() {
        return userType;
    }

    public void setUserType(Integer userType) {
        this.userType = userType;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public Date getUserBirth() {
        return userBirth;
    }

    public void setUserBirth(Date userBirth) {
        this.userBirth = userBirth;
    }

    public Integer getUserSex() {
        return userSex;
    }

    public void setUserSex(Integer userSex) {
        this.userSex = userSex;
    }

    public Integer getUserGrade() {
        return userGrade;
    }

    public void setUserGrade(Integer userGrade) {
        this.userGrade = userGrade;
    }

    public String getUserChips() {
        return userChips;
    }

    public void setUserChips(String userChips) {
        this.userChips = userChips;
    }

    public String getUserIdu() {
        return userIdu;
    }

    public void setUserIdu(String userIdu) {
        this.userIdu = userIdu;
    }

    public Date getUserStartDate() {
        return userStartDate;
    }

    public void setUserStartDate(Date userStartDate) {
        this.userStartDate = userStartDate;
    }

    public Date getUserEndDate() {
        return userEndDate;
    }

    public void setUserEndDate(Date userEndDate) {
        this.userEndDate = userEndDate;
    }

    public Integer getMostUser() {
        return mostUser;
    }

    public void setMostUser(Integer mostUser) {
        this.mostUser = mostUser;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        User other = (User) that;
        return (this.getUserId() == null ? other.getUserId() == null : this.getUserId().equals(other.getUserId()))
                && (this.getUserName() == null ? other.getUserName() == null : this.getUserName().equals(other.getUserName()))
                && (this.getUserType() == null ? other.getUserType() == null : this.getUserType().equals(other.getUserType()))
                && (this.getUserPassword() == null ? other.getUserPassword() == null : this.getUserPassword().equals(other.getUserPassword()))
                && (this.getUserEmail() == null ? other.getUserEmail() == null : this.getUserEmail().equals(other.getUserEmail()))
                && (this.getUserBirth() == null ? other.getUserBirth() == null : this.getUserBirth().equals(other.getUserBirth()))
                && (this.getUserSex() == null ? other.getUserSex() == null : this.getUserSex().equals(other.getUserSex()))
                && (this.getUserGrade() == null ? other.getUserGrade() == null : this.getUserGrade().equals(other.getUserGrade()))
                && (this.getUserChips() == null ? other.getUserChips() == null : this.getUserChips().equals(other.getUserChips()))
                && (this.getUserIdu() == null ? other.getUserIdu() == null : this.getUserIdu().equals(other.getUserIdu()))
                && (this.getUserStartDate() == null ? other.getUserStartDate() == null : this.getUserStartDate().equals(other.getUserStartDate()))
                && (this.getUserEndDate() == null ? other.getUserEndDate() == null : this.getUserEndDate().equals(other.getUserEndDate()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getUserId() == null) ? 0 : getUserId().hashCode());
        result = prime * result + ((getUserName() == null) ? 0 : getUserName().hashCode());
        result = prime * result + ((getUserType() == null) ? 0 : getUserType().hashCode());
        result = prime * result + ((getUserPassword() == null) ? 0 : getUserPassword().hashCode());
        result = prime * result + ((getUserEmail() == null) ? 0 : getUserEmail().hashCode());
        result = prime * result + ((getUserBirth() == null) ? 0 : getUserBirth().hashCode());
        result = prime * result + ((getUserSex() == null) ? 0 : getUserSex().hashCode());
        result = prime * result + ((getUserGrade() == null) ? 0 : getUserGrade().hashCode());
        result = prime * result + ((getUserChips() == null) ? 0 : getUserChips().hashCode());
        result = prime * result + ((getUserIdu() == null) ? 0 : getUserIdu().hashCode());
        result = prime * result + ((getUserStartDate() == null) ? 0 : getUserStartDate().hashCode());
        result = prime * result + ((getUserEndDate() == null) ? 0 : getUserEndDate().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", userId=").append(userId);
        sb.append(", userName=").append(userName);
        sb.append(", userType=").append(userType);
        sb.append(", userPassword=").append(userPassword);
        sb.append(", userEmail=").append(userEmail);
        sb.append(", userBirth=").append(userBirth);
        sb.append(", userSex=").append(userSex);
        sb.append(", userGrade=").append(userGrade);
        sb.append(", userChips=").append(userChips);
        sb.append(", userIdu=").append(userIdu);
        sb.append(", userStartDate=").append(userStartDate);
        sb.append(", userEndDate=").append(userEndDate);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}
package com.library.lsmback.service;

import com.library.lsmback.models.Book;

import java.util.List;

public interface BookService {

    List<Book> selectAll(Integer bookId, String bookName, String bookAuthor, String bookPub);

    int updateBook(Book book);

    int deleteBookById(Integer bookId);

    int addBook(Book book);

    List<Book> selectPopularBook();
}

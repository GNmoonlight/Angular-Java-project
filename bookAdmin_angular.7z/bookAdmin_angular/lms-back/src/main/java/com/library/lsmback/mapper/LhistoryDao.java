package com.library.lsmback.mapper;

import com.library.lsmback.models.Lhistory;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface LhistoryDao {
    int insert(Lhistory record);

    int insertSelective(Lhistory record);

    List<Lhistory> selectByUserId(Integer userId);
}
package com.library.lsmback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LsmBackApplication {

    public static void main(String[] args) {
        SpringApplication.run(LsmBackApplication.class, args);
    }

}

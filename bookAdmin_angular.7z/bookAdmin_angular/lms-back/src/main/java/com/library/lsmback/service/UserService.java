package com.library.lsmback.service;

import com.library.lsmback.models.User;

import java.util.List;

public interface UserService {

    /**
     * 验证密码
     *
     * @param name
     * @param password
     * @return
     */
    int selectByNamePassword(String name, String password);

    /**
     * @param user
     * @return
     */
    int addUser(User user);

    /**
     * @param username
     * @return
     */
    int selectByName(String username);

    User selectAllByName(String username);

    int updateUser(User user);

    List<User> getMostUser();
}

package com.library.lsmback.service.impl;

import com.library.lsmback.mapper.UserDao;
import com.library.lsmback.models.User;
import com.library.lsmback.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserDao userDao;

    /**
     * 验证密码
     *
     * @param username
     * @param password
     * @return
     */
    @Override
    public int selectByNamePassword(String username, String password) {
        return userDao.selectByNamePassword(username, password);
    }

    /**
     * @param user
     * @return
     */
    @Override
    public int addUser(User user) {
        return userDao.insertSelective(user);
    }

    /**
     * @param username
     * @return
     */
    @Override
    public int selectByName(String username) {
        return userDao.selectByName(username);
    }

    @Override
    public User selectAllByName(String username) {
        return userDao.selectAllByName(username);
    }

    @Override
    public int updateUser(User user) {
        return userDao.updateByPrimaryKeySelective(user);
    }

    @Override
    public List<User> getMostUser() {
        return userDao.getMostUser();
    }
}

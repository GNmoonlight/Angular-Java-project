package com.library.lsmback.controller;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.library.lsmback.models.Bhistory;
import com.library.lsmback.models.Book;
import com.library.lsmback.service.BhistoryService;
import com.library.lsmback.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/book")
public class BookController {

    @Autowired
    private BookService bookService;

    @Autowired
    private BhistoryService bhistoryService;

    /**
     * 按检索条件获取图书列表
     *
     * @param pageSize   页面大小
     * @param pageNum    当前页面index
     * @param bookId     图书ID
     * @param bookName   图书名
     * @param bookAuthor 作者
     * @param bookPub    出版社
     * @return
     */
    @RequestMapping(value = "/getAllBooks", method = RequestMethod.POST)
    public PageInfo<Book> getAllBook(
            @RequestParam(value = "pageSize", required = false) Integer pageSize,
            @RequestParam(value = "pageNum", required = false) Integer pageNum,
            @RequestParam(value = "bookId", required = false) Integer bookId,
            @RequestParam(value = "bookName", required = false) String bookName,
            @RequestParam(value = "bookAuthor", required = false) String bookAuthor,
            @RequestParam(value = "bookPub", required = false) String bookPub
    ) {
        //不设定分页信息则返回全部图书列表
        if (pageSize != null && pageNum != null) {
            PageHelper.startPage(pageNum, pageSize);
        }
        return new PageInfo<>(bookService.selectAll(bookId, bookName, bookAuthor, bookPub));
    }

    /**
     * 借书接口
     *
     * @param bookId    图书ID
     * @param userId    用户ID
     * @param bookCount 图书剩余数量
     * @return
     */
    @RequestMapping(value = "/borrowBook", method = RequestMethod.POST)
    public JSONObject borrowBook(
            @RequestParam("bookId") Integer bookId,
            @RequestParam("userId") Integer userId,
            @RequestParam("bookCount") Integer bookCount) {
        JSONObject jsonObject = new JSONObject();
        try {
            Bhistory newBhistory = new Bhistory();
            Book newBook = new Book();
            newBook.setBookId(bookId);
            newBook.setBookCount(bookCount - 1);
            newBhistory.setBookId(bookId);
            newBhistory.setUserId(userId);

            //更新图书数量
            int updateResult = bookService.updateBook(newBook);
            //插入图书借阅记录
            int addBhistoryResult = bhistoryService.insertBhistory(newBhistory);

            if (updateResult == 1 && addBhistoryResult == 1) {
                jsonObject.put("code", 1);
                jsonObject.put("message", "借阅成功");
            } else {
                //不成功则回滚事务
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                jsonObject.put("code", 0);
                jsonObject.put("message", "借阅失败");
            }
        } catch (Exception e) {
            //报错则回滚事务
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
        }
        return jsonObject;
    }

    /**
     * 图书归还接口
     *
     * @param bookId 图书ID
     * @param userId 用户ID
     * @return
     */
    @RequestMapping(value = "/returnBook", method = RequestMethod.POST)
    public JSONObject returnBook(
            @RequestParam("bookId") Integer bookId,
            @RequestParam("userId") Integer userId) {
        JSONObject jsonObject = new JSONObject();
        try {
            //查询当前存在的图书剩余数量
            List<Book> oldBook = bookService.selectAll(bookId, null, null, null);
            int bookCount = oldBook.get(0).getBookCount();
            Bhistory newBhistory = new Bhistory();
            Book newBook = new Book();
            newBook.setBookId(bookId);
            newBook.setBookCount(bookCount + 1);
            newBhistory.setBookId(bookId);
            newBhistory.setUserId(userId);

            //更新图书数量信息
            int updateResult = bookService.updateBook(newBook);
            //更新图书借阅记录信息
            int addBhistoryResult = bhistoryService.returnHistory(newBhistory);

            if (updateResult == 1 && addBhistoryResult == 1) {
                jsonObject.put("code", 1);
                jsonObject.put("message", "归还成功");
            } else {
                //归还失败则回滚事务
                TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                jsonObject.put("code", 0);
                jsonObject.put("message", "归还失败");
            }
        } catch (Exception e) {
            //报错则回顾事务
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
        }
        return jsonObject;
    }

    /**
     * 更新图书信息接口
     *
     * @param newBook 图书对象
     * @return
     */
    @RequestMapping(value = "/updateBook", method = RequestMethod.POST)
    public JSONObject updateBook(@RequestBody Book newBook) {
        JSONObject jsonObject = new JSONObject();

        //更新图书
        int updateResult = bookService.updateBook(newBook);

        if (updateResult == 1) {
            jsonObject.put("code", 1);
            jsonObject.put("message", "更新成功");
        } else {
            jsonObject.put("code", 0);
            jsonObject.put("message", "更新失败");
        }
        return jsonObject;
    }

    /**
     * 删除图书接口
     *
     * @param bookId 图书ID
     * @return
     */
    @RequestMapping(value = "/deleteBook", method = RequestMethod.POST)
    public JSONObject deleteBook(@RequestParam("bookId") Integer bookId) {
        JSONObject jsonObject = new JSONObject();
        //删除图书
        int deleteResult = bookService.deleteBookById(bookId);
        if (deleteResult == 1) {
            jsonObject.put("code", 1);
            jsonObject.put("message", "删除成功");
        } else {
            jsonObject.put("code", 0);
            jsonObject.put("message", "删除失败");
        }
        return jsonObject;
    }

    /**
     * 添加图书接口
     *
     * @param newBook 要添加的图书对象
     * @return
     */
    @RequestMapping(value = "/addBook", method = RequestMethod.POST)
    public JSONObject addBook(@RequestBody Book newBook) {
        JSONObject jsonObject = new JSONObject();
        //查询要添加的图书是否存在
        List<Book> selectResult = bookService.selectAll(null, newBook.getBookName(),
                newBook.getBookAuthor(), newBook.getBookPub());
        //如果存在不做任何操作
        if (!selectResult.isEmpty()) {
            jsonObject.put("code", -1);
            jsonObject.put("message", "此书已存在");
            return jsonObject;
        }
        //添加图书
        int addResult = bookService.addBook(newBook);
        if (addResult == 1) {
            jsonObject.put("code", 1);
            jsonObject.put("message", "添加成功");
        } else {
            jsonObject.put("code", 0);
            jsonObject.put("message", "添加失败");
        }
        return jsonObject;
    }

    /**
     * 获取图书排行接口
     *
     * @return
     */
    @RequestMapping(value = "/getPopularBook", method = RequestMethod.POST)
    public List<Book> getPopularBook() {
        return bookService.selectPopularBook();
    }
}

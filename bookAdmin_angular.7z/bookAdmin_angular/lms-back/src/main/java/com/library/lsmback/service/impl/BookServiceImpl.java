package com.library.lsmback.service.impl;

import com.library.lsmback.mapper.BookDao;
import com.library.lsmback.models.Book;
import com.library.lsmback.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookServiceImpl implements BookService {

    @Autowired
    private BookDao bookDao;

    @Override
    public List<Book> selectAll(Integer bookId, String bookName, String bookAuthor, String bookPub) {
        return bookDao.selectAll(bookId, bookName, bookAuthor, bookPub);
    }

    @Override
    public int updateBook(Book book) {
        return bookDao.updateByPrimaryKeySelective(book);
    }

    @Override
    public int deleteBookById(Integer bookId) {
        return bookDao.deleteByPrimaryKey(bookId);
    }

    @Override
    public int addBook(Book book) {
        return bookDao.insert(book);
    }

    @Override
    public List<Book> selectPopularBook() {
        return bookDao.selectPopularBook();
    }
}

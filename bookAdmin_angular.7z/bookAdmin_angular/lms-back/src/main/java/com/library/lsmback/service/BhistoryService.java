package com.library.lsmback.service;

import com.library.lsmback.models.Bhistory;

public interface BhistoryService {
    int insertBhistory(Bhistory bhistory);

    int returnHistory(Bhistory bhistory);
}

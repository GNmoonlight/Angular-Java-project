package com.library.lsmback.controller;

import com.alibaba.fastjson.JSONObject;
import com.library.lsmback.models.User;
import com.library.lsmback.service.UserService;
import com.library.lsmback.utils.TokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private TokenUtil tokenUtil;

    /**
     * 登录接口
     *
     * @param request HTTP请求对象
     * @return
     */
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public JSONObject login(HttpServletRequest request) {
        JSONObject jsonObject = new JSONObject();
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        //查询用户
        User user = userService.selectAllByName(username);
        //如果密码匹配则登陆成功
        if (user != null && password.equals(user.getUserPassword())) {
            //添加token
            String token = tokenUtil.generateToken(username);
            jsonObject.put("code", 1);
            jsonObject.put("message", "登陆成功");
            jsonObject.put("userType", user.getUserType());
            jsonObject.put("userId", user.getUserId());
            jsonObject.put("token", token);
        } else {
            jsonObject.put("code", 0);
            jsonObject.put("message", "用户名或密码错误");
        }
        return jsonObject;
    }

    /**
     * 注册接口
     *
     * @param request HTTP请求对象
     * @return
     */
    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public JSONObject register(HttpServletRequest request) {
        JSONObject jsonObject = new JSONObject();
        Date birthDate = new Date();
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String userEmail = request.getParameter("userEmail");
        String userBirth = request.getParameter("userBirth");
        String userSex = request.getParameter("userSex");
        String userGrade = request.getParameter("userGrade");
        String userChips = request.getParameter("userChips");
        String userIdu = request.getParameter("userIdu");
        //更具用户名获取用户数量
        int userExist = userService.selectByName(username);
        birthDate.setTime(Date.parse(userBirth));
        //如果用户存在 则跳出接口
        if (userExist > 0) {
            jsonObject.put("code", -1);
            jsonObject.put("message", "用户已存在");
            return jsonObject;
        }
        User newUser = new User();
        newUser.setUserName(username);
        newUser.setUserType(0);
        newUser.setUserPassword(password);
        newUser.setUserEmail(userEmail);
        newUser.setUserBirth(birthDate);
        newUser.setUserSex(Integer.parseInt(userSex));
        newUser.setUserGrade(Integer.parseInt(userGrade));
        newUser.setUserChips(userChips);
        newUser.setUserIdu(userIdu);
        //添加用户
        int flag = userService.addUser(newUser);
        if (flag > 0) {
            jsonObject.put("code", 1);
            jsonObject.put("message", "注册成功");
        } else {
            jsonObject.put("code", 0);
            jsonObject.put("message", "注册失败");
        }
        return jsonObject;
    }

    /**
     * 根据姓名获取用户对象接口
     *
     * @param userName 用户名
     * @return
     */
    @RequestMapping(value = "/getUserByName", method = RequestMethod.POST)
    public User getUserByName(@RequestParam("userName") String userName) {
        //获取用户对象
        return userService.selectAllByName(userName);
    }

    /**
     * 更新用户信息接口
     *
     * @param user 传入用户对象
     * @return
     */
    @RequestMapping(value = "/updateUser", method = RequestMethod.POST)
    public JSONObject updateUser(@RequestBody User user) {
        JSONObject jsonObject = new JSONObject();
        Date birthDate = new Date();
        birthDate.setTime(Date.parse(user.getUserBirth().toString()));
        System.out.println(user.getUserBirth());
        System.out.println(birthDate);
        user.setUserBirth(birthDate);
        //更新有用户信息
        int updateResult = userService.updateUser(user);
        if (updateResult == 1) {
            jsonObject.put("code", 1);
            jsonObject.put("message", "更新成功");
        } else {
            jsonObject.put("code", 0);
            jsonObject.put("message", "更新成功");
        }
        return jsonObject;
    }

    /**
     * 获取用户排行榜接口
     *
     * @return
     */
    @RequestMapping(value = "/getMostUser", method = RequestMethod.POST)
    public List<User> getMostUser() {
        return userService.getMostUser();
    }
}

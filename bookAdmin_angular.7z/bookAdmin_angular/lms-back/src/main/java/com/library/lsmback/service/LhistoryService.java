package com.library.lsmback.service;

import com.library.lsmback.models.Lhistory;

import java.util.List;

public interface LhistoryService {
    int addLhistory(Lhistory lhsitory);

    List<Lhistory> selectByUserId(Integer userId);
}

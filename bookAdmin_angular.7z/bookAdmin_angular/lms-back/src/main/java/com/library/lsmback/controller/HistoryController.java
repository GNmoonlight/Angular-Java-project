package com.library.lsmback.controller;


import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.library.lsmback.models.Bhistory;
import com.library.lsmback.models.Lhistory;
import com.library.lsmback.service.BhistoryService;
import com.library.lsmback.service.LhistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin
@RequestMapping("/history")
public class HistoryController {

    @Autowired
    private BhistoryService bhistoryService;

    @Autowired
    private LhistoryService lhistoryService;

    /**
     * 添加借阅记录接口
     *
     * @param bhistory 借阅记录对象
     * @return
     */
    @RequestMapping(value = "/addBhistory", method = RequestMethod.POST)
    public JSONObject addBhistory(@RequestBody Bhistory bhistory) {
        JSONObject jsonObject = new JSONObject();
        //添加借阅记录
        int addResult = bhistoryService.insertBhistory(bhistory);
        if (addResult == 1) {
            jsonObject.put("code", 1);
            jsonObject.put("message", "添加成功");
        } else {
            jsonObject.put("code", 0);
            jsonObject.put("message", "添加失败");
        }
        return jsonObject;
    }

    /**
     * 归还记录借口
     *
     * @param bhistory 借阅记录对象
     * @return
     */
    @RequestMapping(value = "/returnBhistory", method = RequestMethod.POST)
    public JSONObject returnBHistory(@RequestBody Bhistory bhistory) {
        JSONObject jsonObject = new JSONObject();
        //更新借阅记录
        int addResult = bhistoryService.returnHistory(bhistory);
        if (addResult == 1) {
            jsonObject.put("code", 1);
            jsonObject.put("message", "更新成功");
        } else {
            jsonObject.put("code", 0);
            jsonObject.put("message", "更行失败");
        }
        return jsonObject;
    }

    /**
     * 根据用户ID获取登录记录接口
     *
     * @param userId   用户ID
     * @param pageSize 页面大小
     * @param pageNum  当前页面Index
     * @return
     */
    @RequestMapping(value = "/getLhistoryByUserId", method = RequestMethod.POST)
    public PageInfo<Lhistory> getLhistoryByUserId(@RequestParam(value = "userId", required = false)
                                                          Integer userId,
                                                  @RequestParam(value = "pageSize", required = false)
                                                          Integer pageSize,
                                                  @RequestParam(value = "pageNum", required = false)
                                                          Integer pageNum) {
        //未设定分页信息则不分页
        if (pageSize != null && pageNum != null) {
            PageHelper.startPage(pageNum, pageSize);
        }
        return new PageInfo<>(lhistoryService.selectByUserId(userId));
    }
}

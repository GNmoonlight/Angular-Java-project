package com.library.lsmback.interceptor;

import com.library.lsmback.utils.TokenUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class TokenInterceptor implements HandlerInterceptor {

    private final TokenUtil tokenUtil;

    public TokenInterceptor(TokenUtil tokenUtil) {
        this.tokenUtil = tokenUtil;
    }

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        tokenUtil.verifyToken(request.getHeader("token"));

        if (TokenUtil.result) {
            return true;
        } else {
            response.setStatus(403);
            logger.error(TokenUtil.message);
            return false;
        }
    }
}

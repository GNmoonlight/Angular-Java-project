package com.library.lsmback.service.impl;

import com.library.lsmback.mapper.LhistoryDao;
import com.library.lsmback.models.Lhistory;
import com.library.lsmback.service.LhistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LhistoryServiceImpl implements LhistoryService {

    @Autowired
    private LhistoryDao lhistoryDao;

    @Override
    public int addLhistory(Lhistory lhsitory) {
        return lhistoryDao.insert(lhsitory);
    }

    @Override
    public List<Lhistory> selectByUserId(Integer userId) {
        return lhistoryDao.selectByUserId(userId);
    }
}

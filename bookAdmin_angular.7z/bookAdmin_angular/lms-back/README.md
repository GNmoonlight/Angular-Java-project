下载lombok.jar，和eclipse.ini放一起（Eclipse安装目录下）

下载地址：https://www.projectlombok.org/all-versions

 



执行 java -jar lombok.jar，会弹出安装界面

选择eclipse的安装目录

点击Install / Update





重启eclipse

Clean工程

检查eclipse.ini安装后的配置信息

https://blog.csdn.net/github_39325328/article/details/94552200 参照


